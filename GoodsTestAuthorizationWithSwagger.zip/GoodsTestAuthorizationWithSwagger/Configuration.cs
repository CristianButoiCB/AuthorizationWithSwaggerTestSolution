﻿namespace GoodsTest
{
    public class GoodsConfiguration
    {
        public string BaseUrl { get; set; }
        public string ConnectionString { get; set; }
    }

}