﻿namespace GoodsTest
{
    public class StartUp
    {
    }
}
